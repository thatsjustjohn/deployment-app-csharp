# Simple C# Web Application

## Build 
- Run the build to generate the .jar file 
  - ``
  
## Run
- Execute the application 
  - ``

## Test
- Run the tests
  - `./vendor/bin/phpunit --bootstrap vendor/autoload.php index.test.php`
