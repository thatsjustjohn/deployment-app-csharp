using System;
using Xunit;

namespace basic_web_app_test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            Assert.Equal(1, 1);
        }
    }
}
